// src/pages/Admin.js
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { onSnapshot, collection, query, where, doc, setDoc, getDocs, orderBy, limit } from "firebase/firestore";
import { db } from "../firebase/firebaseConfig";
import { useAdmin } from "../layouts/AdminLayout";
import { logActivity } from "../utils/logActivity";
import { Users, Files, Handshake, Newspaper, UserPlus, MailCheck, ChevronRight } from "lucide-react";

const StatCard = ({ icon, title, value, color }) => (
    <div style={{...styles.statCard, borderLeft: `4px solid ${color}`}}>
        <div style={{...styles.statIconWrapper, backgroundColor: `${color}20`, color }}>{icon}</div>
        <div>
            <p style={styles.statTitle}>{title}</p>
            <p style={styles.statValue}>{value}</p>
        </div>
    </div>
);

const ToggleSwitch = ({ label, status, onToggle }) => (
    <div style={styles.toggleContainer}>
        <label style={{flexGrow: 1}}>{label}</label>
        <label className="switch" style={styles.switch}>
            <input type="checkbox" checked={status} onChange={onToggle} />
            <span className="slider round" style={{...styles.slider, ...styles.sliderRound}}></span>
        </label>
    </div>
);

const Admin = () => {
    const { profil } = useAdmin();
    const [stats, setStats] = useState({ anggota: 0, dokumen: 0, layanan: 0, berita: 0 });
    const [histori, setHistori] = useState([]);
    const [pendingItems, setPendingItems] = useState({ users: 0, requests: 0 });
    const [settings, setSettings] = useState({ isDirektoriPublished: true, isEvotingPublished: true, isFeaturedServicesPublished: true });

    useEffect(() => {
        let unsubscribers = [];
        if (profil.role === 'master') {
            const pendingUsersQuery = query(collection(db, "users"), where("role", "in", ["pending", "pending_panitia"]));
            const requestsQuery = query(collection(db, "pemilihan_requests"));
            const unsubUsers = onSnapshot(pendingUsersQuery, (snapshot) => setPendingItems(prev => ({ ...prev, users: snapshot.size })));
            const unsubRequests = onSnapshot(requestsQuery, (snapshot) => setPendingItems(prev => ({ ...prev, requests: snapshot.size })));
            unsubscribers.push(unsubUsers, unsubRequests);
        }
        
        const fetchStats = async () => {
            const [strukturSnap, dokumenSnap, layananSnap, beritaSnap] = await Promise.all([
                getDocs(collection(db, 'struktur')), getDocs(collection(db, 'dokumen')),
                getDocs(collection(db, 'layanan')), getDocs(collection(db, 'berita'))
            ]);
            const totalAnggota = strukturSnap.docs.reduce((acc, doc) => acc + (doc.data().anggota?.length || 0), 0);
            setStats({ anggota: totalAnggota, dokumen: dokumenSnap.size, layanan: layananSnap.size, berita: beritaSnap.size });
        };
        fetchStats();

        const historiQuery = query(collection(db, 'histori'), orderBy('timestamp', 'desc'), limit(5));
        const unsubscribeHistori = onSnapshot(historiQuery, (snapshot) => setHistori(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))));
        unsubscribers.push(unsubscribeHistori);

        const settingsDocRef = doc(db, 'settings', 'general');
        const unsubSettings = onSnapshot(settingsDocRef, (docSnap) => { if (docSnap.exists()) setSettings(docSnap.data()); });
        unsubscribers.push(unsubSettings);

        return () => unsubscribers.forEach(unsub => unsub());
    }, [profil]);
    
    const handleToggleSetting = async (settingName, currentValue) => {
        const newStatus = !currentValue;
        try {
            await setDoc(doc(db, 'settings', 'general'), { [settingName]: newStatus }, { merge: true });
            await logActivity(`Mengubah status publikasi ${settingName} menjadi ${newStatus}`);
        } catch (error) { console.error("Gagal mengubah pengaturan:", error); }
    };
    
    const formatTimestamp = (timestamp) => {
        if (!timestamp) return '';
        return new Date(timestamp.seconds * 1000).toLocaleString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    };

    return (
        // ✅ Menggunakan div pembungkus utama agar styling lebih konsisten
        <div className="admin-dashboard-page">
            <div style={styles.header}>
                {/* ✅ Memberi className agar ukuran font bisa diatur secara responsif */}
                <h1 className="page-title" style={styles.pageTitle}>Ringkasan Dasbor</h1>
            </div>
            
            {/* ✅ Memberi className agar lebih mudah di-style */}
            <div className="stats-grid" style={styles.statsGrid}>
                <StatCard title="Total Anggota" value={stats.anggota} color="#3b82f6" icon={<Users size={24} />} />
                <StatCard title="Dokumen" value={stats.dokumen} color="#1d4ed8" icon={<Files size={24} />} />
                <StatCard title="Layanan" value={stats.layanan} color="#16a34a" icon={<Handshake size={24} />} />
                <StatCard title="Berita" value={stats.berita} color="#f59e0b" icon={<Newspaper size={24} />} />
            </div>

            {/* ✅ Memberi className agar lebih mudah di-style */}
            <div className="main-grid">
                <div style={styles.card}>
                    <h3 style={styles.cardTitle}>Aktivitas Terbaru</h3>
                    <div>
                        {histori.length > 0 ? histori.map(item => (
                            <div key={item.id} style={styles.activityItem}>
                                <div>
                                    <p style={styles.itemName}>{item.action}</p>
                                    <p style={styles.itemDetail}>Oleh: {item.oleh}</p>
                                </div>
                                <p style={styles.itemDetail}>{formatTimestamp(item.timestamp)}</p>
                            </div>
                        )) : <p style={styles.emptyText}>Belum ada aktivitas.</p>}
                    </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                    {profil?.role === 'master' && (
                        <div style={{...styles.card, backgroundColor: '#fffbe6', borderLeft: '4px solid #f59e0b'}}>
                            <h3 style={{...styles.cardTitle, color: '#b45309'}}>Tindakan Diperlukan</h3>
                            <Link to="/admin/kelola-admin" style={styles.actionItemLink} className="action-item-link">
                                <div style={styles.actionItemContent}>
                                    <UserPlus size={20} />
                                    <p>{pendingItems.users} Pendaftar Baru</p>
                                </div>
                                <ChevronRight size={20} />
                            </Link>
                            <Link to="/admin/manajemen-voting" style={styles.actionItemLink} className="action-item-link">
                                <div style={styles.actionItemContent}>
                                    <MailCheck size={20} />
                                    <p>{pendingItems.requests} Permintaan E-Voting</p>
                                </div>
                                <ChevronRight size={20} />
                            </Link>
                        </div>
                    )}
                    {profil?.role === 'master' && (
                        <div style={styles.card}>
                            <h3 style={styles.cardTitle}>Pengaturan Global</h3>
                            <div style={{display: 'flex', flexDirection: 'column', gap: '16px'}}>
                                <ToggleSwitch label="Layanan Digital Terpadu" status={settings.isPublishedFeaturedServices ?? true} onToggle={() => handleToggleSetting('isPublishedFeaturedServices', settings.isPublishedFeaturedServices)} />
                                <ToggleSwitch label="Publikasi Direktori" status={settings.isDirektoriPublished} onToggle={() => handleToggleSetting('isDirektoriPublished', settings.isDirektoriPublished)} />
                                <ToggleSwitch label="Publikasi E-Voting" status={settings.isEvotingPublished} onToggle={() => handleToggleSetting('isEvotingPublished', settings.isEvotingPublished)} />
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const styles = {
    header: { marginBottom: '32px' },
    // Ukuran font default dipindahkan ke CSS Class
    pageTitle: { color: '#1e293b', fontWeight: '700', margin: 0 },
    // Grid untuk 4 kartu statistik di atas
    statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '24px', marginBottom: '32px' },
    statCard: { display: 'flex', alignItems: 'center', gap: '16px', backgroundColor: '#ffffff', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)' },
    statIconWrapper: { borderRadius: '8px', width: '48px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'center' },
    statValue: { margin: 0, color: '#1e293b', fontSize: '1.75rem', fontWeight: '700' },
    statTitle: { margin: '4px 0 0', color: '#64748b', fontSize: '0.9rem' },
    // Grid untuk konten utama tidak lagi di-style di sini, tapi di CSS class
    card: { backgroundColor: '#ffffff', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)' },
    cardTitle: { margin: '0 0 16px 0', color: '#1e293b', fontSize: '1.25rem', fontWeight: '600', borderBottom: '1px solid #f1f5f9', paddingBottom: '16px' },
    activityItem: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid #f1f5f9' },
    itemName: { margin: 0, fontWeight: '500', color: '#1e293b' },
    itemDetail: { margin: '4px 0 0', fontSize: '0.85rem', color: '#64748b' },
    actionItemLink: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', borderRadius: '8px', cursor: 'pointer', backgroundColor: '#fef3c7', color: '#92400e', fontWeight: '600', marginBottom: '8px', textDecoration: 'none' },
    actionItemContent: { display: 'flex', alignItems: 'center', gap: '8px' },
    toggleContainer: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px', borderRadius: '8px', border: '1px solid #e2e8f0', color: '#334155', fontWeight: '500' },
    switch: { position: 'relative', display: 'inline-block', width: '44px', height: '24px' },
    slider: { position: 'absolute', cursor: 'pointer', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#cbd5e0', transition: '.4s' },
    sliderRound: { borderRadius: '24px' },
    emptyText: { textAlign: 'center', color: '#94a3b8', padding: '20px 0' },
};

// ✅ CSS STYLING DIPERBARUI DENGAN LOGIKA RESPONSIVE
const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
  
  .action-item-link:hover { background-color: #fde68a; }

  /* Tampilan Mobile (Default) */
  .page-title {
    font-size: 1.75rem; /* Ukuran judul lebih kecil di HP */
  }

  .main-grid {
    display: grid;
    grid-template-columns: 1fr; /* 1 kolom untuk mobile */
    gap: 24px;
    align-items: start;
  }
  
  /* Tampilan Desktop (Layar lebih besar dari 900px) */
  @media (min-width: 900px) {
    .page-title {
      font-size: 2rem; /* Kembalikan ukuran judul ke normal di desktop */
    }

    .main-grid {
      grid-template-columns: 2fr 1fr; /* 2 kolom untuk desktop */
    }
  }

  /* Styling untuk Toggle Switch */
  input[type="checkbox"] { position: absolute; opacity: 0; width: 0; height: 0; }
  .slider:before {
    position: absolute; content: ""; height: 18px; width: 18px; left: 3px;
    bottom: 3px; background-color: white; transition: .4s; border-radius: 50%;
  }
  input:checked + .slider { background-color: #1d4ed8; }
  input:checked + .slider:before { transform: translateX(20px); }
`;
document.head.appendChild(styleSheet);

export default Admin;