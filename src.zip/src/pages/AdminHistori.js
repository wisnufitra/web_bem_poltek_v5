// src/pages/AdminHistori.js
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { db, auth } from '../firebase/firebaseConfig';
import { collection, onSnapshot, query, orderBy, doc, deleteDoc, getDocs, writeBatch } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { logActivity } from '../utils/logActivity';
import { ArchiveX, Download, Trash2, Search, Users, ListFilter, CalendarDays, ChevronLeft, ChevronRight, ArrowLeft, User, Clock } from 'lucide-react';

// --- Komponen-komponen UI (tidak berubah) ---
const LoadingSpinner = () => ( <div style={styles.loadingContainer}><div className="spinner"></div></div> );
const EmptyState = ({ message }) => ( <div style={styles.emptyState}><ArchiveX size={48} style={{ color: '#9ca3af', marginBottom: '16px' }} /><p style={{ color: '#6b7280', fontWeight: '500', fontSize: '1.1rem' }}>{message}</p></div> );
const ConfirmationModal = ({ message, onConfirm, onCancel, confirmText, confirmColor }) => ( <div style={styles.modalOverlay}><div style={styles.modalContent}><p style={{ marginBottom: '30px', color: '#1f2937', fontSize: '1.1rem' }}>{message}</p><div><button onClick={onCancel} style={styles.modalCancelButton} className="modal-button">Batal</button><button onClick={onConfirm} style={{ ...styles.modalConfirmButton, backgroundColor: confirmColor || '#dc2626' }} className="modal-button">{confirmText || 'Ya, Lanjutkan'}</button></div></div></div> );

const AdminHistori = () => {
    const navigate = useNavigate();
    const [histori, setHistori] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [userRole, setUserRole] = useState(null);
    const [selectedItems, setSelectedItems] = useState([]);
    const itemsPerPage = 10;
    const [searchTerm, setSearchTerm] = useState('');
    const [userFilter, setUserFilter] = useState('Semua');
    const [actionFilter, setActionFilter] = useState('Semua');
    const [dateFilter, setDateFilter] = useState({ start: '', end: '' });
    const [uniqueUsers, setUniqueUsers] = useState([]);
    const [confirmProps, setConfirmProps] = useState({ show: false });

    // --- Hooks useEffect dan Functions (tidak ada perubahan logika) ---
    useEffect(() => {
        const unsubscribeAuth = onAuthStateChanged(auth, user => {
            if (user) {
                const userDocRef = doc(db, 'users', user.uid);
                onSnapshot(userDocRef, (docSnap) => {
                    if (docSnap.exists()) setUserRole(docSnap.data().role);
                });
            } else { navigate('/login'); }
        });
        const q = query(collection(db, 'histori'), orderBy('timestamp', 'desc'));
        const unsubscribeFirestore = onSnapshot(q, (snapshot) => {
            const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setHistori(list);
            const users = [...new Set(list.map(item => item.oleh))];
            setUniqueUsers(users);
            setLoading(false);
        });
        return () => { unsubscribeAuth(); unsubscribeFirestore(); };
    }, [navigate]);

    const filteredHistori = useMemo(() => {
        return histori.filter(item => {
            const matchesSearch = item.action.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesUser = userFilter === 'Semua' || item.oleh === userFilter;
            const matchesAction = actionFilter === 'Semua' || item.action.toLowerCase().startsWith(actionFilter.toLowerCase());
            let matchesDate = true;
            if (dateFilter.start && item.timestamp) matchesDate = item.timestamp.toDate() >= new Date(dateFilter.start);
            if (dateFilter.end && item.timestamp) {
                const endDate = new Date(dateFilter.end);
                endDate.setDate(endDate.getDate() + 1);
                matchesDate = matchesDate && item.timestamp.toDate() < endDate;
            }
            return matchesSearch && matchesUser && matchesAction && matchesDate;
        });
    }, [histori, searchTerm, userFilter, actionFilter, dateFilter]);

    const formatTimestamp = (timestamp) => {
        if (!timestamp) return 'Waktu tidak tersedia';
        return new Date(timestamp.seconds * 1000).toLocaleString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    };

    const formatDateForFile = (date) => new Date(date).toISOString().replace(/:/g, '-').slice(0, 19);
    const handleSelectAllOnPage = () => {
        const allItemIdsOnPage = currentItems.map(item => item.id);
        const allSelected = allItemIdsOnPage.every(id => selectedItems.includes(id));
        if (allSelected) {
            setSelectedItems(prev => prev.filter(id => !allItemIdsOnPage.includes(id)));
        } else {
            setSelectedItems(prev => [...new Set([...prev, ...allItemIdsOnPage])]);
        }
    };
    const handleSelectItem = (id) => setSelectedItems(prev => prev.includes(id) ? prev.filter(itemId => itemId !== id) : [...prev, id]);
    const handleDeleteSelected = async () => {
        if (selectedItems.length === 0) return;
        setConfirmProps({ show: true, message: `Anda yakin ingin menghapus ${selectedItems.length} log aktivitas yang dipilih?`,
            onConfirm: async () => {
                const batch = writeBatch(db);
                selectedItems.forEach(id => batch.delete(doc(db, 'histori', id)));
                await batch.commit();
                await logActivity(`Menghapus ${selectedItems.length} log aktivitas`);
                setSelectedItems([]);
                setConfirmProps({ show: false });
            }
        });
    };
    const handleClearAll = async () => {
        setConfirmProps({ show: true, message: "ANDA YAKIN ingin menghapus SEMUA histori aktivitas? Tindakan ini tidak dapat diurungkan.",
            onConfirm: async () => {
                const snapshot = await getDocs(collection(db, 'histori'));
                const batch = writeBatch(db);
                snapshot.docs.forEach(d => batch.delete(d.ref));
                await batch.commit();
                await logActivity("Menghapus semua histori aktivitas");
                setConfirmProps({ show: false });
            }
        });
    };
    const handleExportCSV = async () => {
        if (filteredHistori.length === 0) return alert("Tidak ada data untuk diekspor.");
        setConfirmProps({ show: true, message: `Yakin ingin mengunduh ${filteredHistori.length} data histori aktivitas?`, confirmText: "Ya, Unduh", confirmColor: '#28a745',
            onConfirm: () => {
                const headers = ["Waktu", "Aksi", "Oleh"];
                const rows = filteredHistori.map(item => [`"${formatTimestamp(item.timestamp)}"`, `"${item.action.replace(/"/g, '""')}"`, `"${item.oleh}"`]);
                let csvContent = "data:text/csv;charset=utf-8," + headers.join(",") + "\n" + rows.join("\n");
                const link = document.createElement("a");
                link.setAttribute("href", encodeURI(csvContent));
                link.setAttribute("download", `histori_aktivitas_${formatDateForFile(new Date())}.csv`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                setConfirmProps({ show: false });
            }
        });
    };
    const currentItems = useMemo(() => filteredHistori.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage), [filteredHistori, currentPage, itemsPerPage]);
    const totalPages = Math.ceil(filteredHistori.length / itemsPerPage);
    const paginate = (pageNumber) => setCurrentPage(page => Math.max(1, Math.min(pageNumber, totalPages)));
    
    return (
        <div className="histori-page">
            <div className="histori-container">
                {confirmProps.show && <ConfirmationModal {...confirmProps} onCancel={() => setConfirmProps({ show: false })} />}
                
                <header className="page-header">
                    <h1 className="page-title">Histori Aktivitas</h1>
                    {userRole === 'master' && (
                        <div className="header-actions">
                            <button onClick={handleExportCSV} className="button button-success"><Download size={16} />Ekspor CSV</button>
                            <button onClick={handleClearAll} className="button button-danger"><Trash2 size={16} />Bersihkan Semua</button>
                        </div>
                    )}
                </header>

                <div className="card">
                    <h2 className="card-title">Filter & Pencarian</h2>
                    <div className="filter-panel">
                        <div className="input-with-icon"><Search size={18} /><input type="text" placeholder="Cari aktivitas..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} /></div>
                        <div className="input-with-icon"><Users size={18} /><select value={userFilter} onChange={(e) => setUserFilter(e.target.value)}><option value="Semua">Semua Pengguna</option>{uniqueUsers.map(user => <option key={user} value={user}>{user}</option>)}</select></div>
                        <div className="input-with-icon"><ListFilter size={18} /><select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)}><option value="Semua">Semua Aksi</option><option value="Menambah">Menambah</option><option value="Mengedit">Mengedit</option><option value="Menghapus">Menghapus</option></select></div>
                        
                        <div className="date-filter-group">
                            <div className="form-group">
                                <label>Mulai</label>
                                <div className="input-with-icon"><CalendarDays size={18} /><input type="date" value={dateFilter.start} onChange={e => setDateFilter({...dateFilter, start: e.target.value})}/></div>
                            </div>
                            <div className="form-group">
                                <label>Selesai</label>
                                <div className="input-with-icon"><CalendarDays size={18} /><input type="date" value={dateFilter.end} onChange={e => setDateFilter({...dateFilter, end: e.target.value})}/></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="card">
                    <div className="list-header">
                        <h2 className="card-title">Log Aktivitas</h2>
                        {selectedItems.length > 0 && (
                            <button onClick={handleDeleteSelected} className="button button-danger-outline"><Trash2 size={16} /> Hapus ({selectedItems.length})</button>
                        )}
                    </div>
                    
                    {loading ? <LoadingSpinner/> : filteredHistori.length === 0 ? <EmptyState message="Tidak ada histori yang sesuai." /> : (
                        <div className="history-list">
                            <div className="history-list-header">
                                <input type="checkbox" onChange={handleSelectAllOnPage} checked={currentItems.length > 0 && currentItems.every(item => selectedItems.includes(item.id))} />
                                <span className="col-aksi">Aksi</span>
                                <span className="col-oleh">Oleh</span>
                                <span className="col-waktu">Waktu</span>
                            </div>
                            {currentItems.map((item) => (
                                <div key={item.id} className={`history-item ${selectedItems.includes(item.id) ? 'selected' : ''}`}>
                                    <input type="checkbox" checked={selectedItems.includes(item.id)} onChange={() => handleSelectItem(item.id)} />
                                    <div className="item-content">
                                        <p className="item-action">{item.action}</p>
                                        <p className="item-meta item-meta-oleh"><User size={14} />{item.oleh}</p>
                                        <p className="item-meta item-meta-waktu"><Clock size={14} />{formatTimestamp(item.timestamp)}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {totalPages > 1 && (
                    <div className="pagination">
                        <button onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1}><ChevronLeft size={18} /></button>
                        <span>Halaman {currentPage} dari {totalPages}</span>
                        <button onClick={() => paginate(currentPage + 1)} disabled={currentPage === totalPages}><ChevronRight size={18} /></button>
                    </div>
                )}
                
                <button onClick={() => navigate("/admin")} className="button button-secondary button-full-width"><ArrowLeft size={16} /> Kembali ke Dasbor</button>
            </div>
        </div>
    );
};

const styles = {
    loadingContainer: { display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '40px' },
    emptyState: { textAlign: 'center', padding: '40px 20px', backgroundColor: '#f8f9fa', borderRadius: '8px' },
    modalOverlay: { position: "fixed", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(15, 23, 42, 0.6)", backdropFilter: 'blur(4px)', display: "flex", justifyContent: "center", alignItems: "center", zIndex: 3000 },
    modalContent: { backgroundColor: 'white', padding: "24px", borderRadius: "12px", width: "90%", maxWidth: "400px", textAlign: 'center', boxShadow: '0 10px 25px rgba(0,0,0,0.1)' },
    modalCancelButton: { padding: "10px 20px", border: "1px solid #e2e8f0", borderRadius: "8px", cursor: "pointer", fontWeight: '600', margin: '0 8px', backgroundColor: '#f1f5f9', color: '#475569' },
    modalConfirmButton: { padding: "10px 20px", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: '600', margin: '0 8px', color: 'white' },
};

const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
    .histori-page { font-family: 'Inter', sans-serif; background-color: #f8fafc; padding: 20px; }
    .histori-container { max-width: 1200px; margin: 0 auto; }
    .page-title { color: #1e293b; font-size: 1.75rem; font-weight: 700; margin: 0; }
    .card { background-color: white; padding: 24px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; margin-bottom: 24px; }
    .card-title { margin: 0 0 16px 0; color: #1e293b; font-size: 1.25rem; font-weight: 600; }
    .button { display: inline-flex; align-items: center; gap: 8px; padding: 10px 16px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 0.9rem; transition: all 0.2s; }
    .button:hover { filter: brightness(0.95); transform: translateY(-1px); }
    .button-success { background-color: #28a745; color: white; }
    .button-danger { background-color: #dc3545; color: white; }
    .button-danger-outline { background-color: transparent; color: #dc3545; border: 1px solid #dc3545; }
    .button-secondary { background-color: #6c757d; color: white; }
    .button-full-width { width: 100%; justify-content: center; }
    .modal-button:hover { filter: brightness(0.9); }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .spinner { width: 40px; height: 40px; border-radius: 50%; border: 4px solid #e9ecef; border-top-color: #1d4ed8; animation: spin 1s linear infinite; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .header-actions { display: flex; flex-wrap: wrap; gap: 10px; }
    .filter-panel { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }
    .input-with-icon { position: relative; display: flex; align-items: center; }
    .input-with-icon svg { position: absolute; left: 12px; color: #9ca3af; pointer-events: none; }
    .input-with-icon input, .input-with-icon select { width: 100%; box-sizing: border-box; padding: 10px 12px 10px 40px; border-radius: 8px; border: 1px solid #cbd5e0; font-size: 0.9rem; }
    .date-filter-group { display: grid; grid-template-columns: 1fr; gap: 16px; }
    .form-group label { font-size: 0.85rem; font-weight: 500; color: #475569; margin-bottom: 6px; display: block; }
    .list-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; flex-wrap: wrap; gap: 16px; }
    .history-list-header { display: none; }
    .history-item { background-color: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 12px; display: flex; gap: 16px; align-items: center; transition: all 0.2s; }
    .history-item:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.08); }
    .history-item.selected { background-color: #eef2ff; border-color: #818cf8; }
    .history-item input[type="checkbox"] { transform: scale(1.2); flex-shrink: 0; }
    .item-content { display: flex; flex-direction: column; gap: 8px; }
    .item-action { font-weight: 600; color: #1f2937; margin: 0; }
    .item-meta { font-size: 0.85rem; color: #6b7280; display: flex; align-items: center; gap: 6px; margin: 0; }
    .pagination { display: flex; justify-content: center; align-items: center; gap: 10px; margin-top: 24px; }
    .pagination button { background: white; border: 1px solid #dee2e6; border-radius: 6px; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
    .pagination button:disabled { cursor: not-allowed; opacity: 0.5; }

    @media (min-width: 768px) {
        /* ✅ PERBAIKAN 1: Filter tanggal meminta ruang 2 kolom agar tidak keluar container */
        .date-filter-group {
            grid-template-columns: 1fr 1fr;
            grid-column: span 2;
        }
    }

    @media (min-width: 900px) {
        .histori-page { padding: 40px; }
        .page-title { font-size: 2.25rem; }
        
        /* ✅ PERBAIKAN 2: Header dan item list menggunakan layout grid yang sama persis */
        .history-list-header, .history-item {
            display: grid;
            grid-template-columns: 40px 1fr 250px 250px;
            gap: 16px;
            align-items: center;
            padding: 12px 16px;
        }
        .history-list-header {
             display: grid; /* Pastikan display grid, bukan flex */
             background-color: #f8f9fa;
             font-weight: 600; 
             color: #495057; 
             border: 1px solid #e2e8f0;
        }
        .history-item .item-content { display: contents; }
        .item-action { grid-column: 2; }
        .item-meta-oleh { grid-column: 3; }
        .item-meta-waktu { grid-column: 4; }
        .item-meta svg { display: none; }
    }
`;
document.head.appendChild(styleSheet);


export default AdminHistori;