// src/layouts/AdminLayout.js
import React, { useState, useEffect, createContext, useContext, useMemo } from 'react';
import { NavLink, Outlet, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase/firebaseConfig';
import LoadingSpinner from '../components/LoadingSpinner';

import {
    LayoutDashboard, Network, Newspaper, FolderKanban, Handshake,
    Archive, CalendarDays, FileCheck2, Users, Vote, Info, LogOut, Menu, X,
    ChevronDown, Landmark, ClipboardList, Settings, CheckCircle2
} from 'lucide-react';

const AdminContext = createContext();
export const useAdmin = () => useContext(AdminContext);

const AdminLayout = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [profil, setProfil] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isSidebarOpen, setSidebarOpen] = useState(false);

    const [openMenus, setOpenMenus] = useState({});

    useEffect(() => {
        if (location.pathname.startsWith('/admin/anggaran')) {
            setOpenMenus(prev => ({ ...prev, keterbukaanInformasi: true }));
        }
        if (location.pathname.startsWith('/admin/proker')) {
            setOpenMenus(prev => ({ ...prev, keterbukaanInformasi: true }));
        }
        if (location.pathname.startsWith('/admin/risalah')) {
            setOpenMenus(prev => ({ ...prev, keterbukaanInformasi: true }));
        }
    }, [location.pathname]);

    const MAIN_HEADER_HEIGHT = '8px'; 
    const REAL_NAVBAR_HEIGHT = '88px';

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            if (user) {
                const docRef = doc(db, 'users', user.uid);
                const unsubProfile = onSnapshot(docRef, (docSnap) => {
                    if (docSnap.exists()) {
                        const userData = docSnap.data();
                        if (userData.role === 'admin' || userData.role === 'master') {
                            setProfil(userData);
                        } else { navigate('/'); }
                    } else { navigate('/login'); }
                    setLoading(false);
                });
                return () => unsubProfile();
            } else { navigate('/login'); }
        });
        return () => unsubscribe();
    }, [navigate]);
    
    const closeSidebar = () => setSidebarOpen(false);

    const handleLogout = () => {
        closeSidebar();
        signOut(auth).then(() => navigate("/login"));
    };

    const toggleMenu = (menuName) => {
        setOpenMenus(prev => ({ ...prev, [menuName]: !prev[menuName] }));
    };

    const isAllowed = useMemo(() => (requiredDivisions = []) => {
        if (!profil) return false;
        if (profil.role === 'master') return true;
        return requiredDivisions.includes(profil.kementerian);
    }, [profil]);

    const navLinks = [
        { to: '/admin', text: 'Ringkasan', icon: <LayoutDashboard size={20} /> },
        { to: 'kelola-publikasi', text: 'Verifikasi Publikasi', icon: <CheckCircle2 size={20} /> },
        { to: 'struktur', text: 'Kelola Struktur', icon: <Network size={20} /> },
        { to: 'kelola-berita', text: 'Kelola Berita', icon: <Newspaper size={20} /> },
        { to: 'dokumen', text: 'Kelola Dokumen', icon: <FolderKanban size={20} /> },
        { to: 'layanan', text: 'Kelola Layanan', icon: <Handshake size={20} /> },
        { 
            to: 'peminjaman-sc', 
            text: 'Kelola Peminjaman SC', 
            icon: <ClipboardList size={20} />,
            required: ['Kementerian Pemuda dan Olahraga (PORA)'] // <-- Aturan akses
        },
    ];
    
    const keterbukaanInformasiLinks = [
            { 
                to: 'anggaran', 
                text: 'Kelola Anggaran', 
                icon: <Landmark size={20} />,
                required: ['Kementerian Keuangan'] // <-- Aturan akses
            },
            { to: 'proker', text: 'Kelola Proker', icon: <Landmark size={20} /> },
            { to: 'risalah-rapat', text: 'Kelola Risalah', icon: <Landmark size={20} /> },
            { to: 'aset-bem', text: 'Kelola Aset', icon: <Landmark size={20} /> },
    ];

    const specialAccessLinks = [
        { to: 'berkas', text: 'Kelola Berkas KM', icon: <Archive size={20} />, required: ['Kementerian Dalam Negeri', 'Kementerian Keuangan', 'Sekretariat Jenderal'] },
        { to: 'kelola-penanggalan', text: 'Kelola Penanggalan', icon: <CalendarDays size={20} />, required: ['Kementerian Dalam Negeri'] },
        { to: 'kelola-form-berkas', text: 'Kelola Form Berkas', icon: <FileCheck2 size={20} />, required: ['Sekretariat Jenderal'] },
    ];

    const masterLinks = [
        { to: 'kelola-admin', text: 'Kelola Pengguna', icon: <Users size={20} /> },
        { to: 'manajemen-voting', text: 'Manajemen E-Voting', icon: <Vote size={20} /> },
        { to: 'kelola-tentang', text: 'Kelola Halaman Tentang', icon: <Info size={20} /> },
        { to: 'settings', text: 'Setting Repository', icon: <Settings size={20} /> },
    ];

    if (loading || !profil) return <LoadingSpinner />;
    
    const renderNavLink = (item) => (
      <NavLink 
        key={item.to} 
        to={item.to} 
        end={item.to === '/admin'} 
        style={({isActive}) => isActive ? styles.activeLink : styles.navLink} 
        className="nav-link"
        onClick={closeSidebar}
      >
        {item.icon}
        <span>{item.text}</span>
      </NavLink>
    );
    
    const styles = {
        layout: { display: 'flex', minHeight: `calc(100vh - ${REAL_NAVBAR_HEIGHT})`, backgroundColor: '#f8fafc', position: 'relative', marginTop: MAIN_HEADER_HEIGHT },
        sidebar: { 
            position: 'fixed',
            top: REAL_NAVBAR_HEIGHT,
            left: 0,
            width: '280px', 
            height: `calc(100vh - ${REAL_NAVBAR_HEIGHT})`,
            backgroundColor: '#1e293b', 
            color: '#e2e8f0', 
            padding: '20px', 
            display: 'flex', 
            flexDirection: 'column',
            zIndex: 1100,
            transform: 'translateX(-100%)',
            transition: 'transform 0.3s ease-in-out',
        },
        sidebarOpen: {
            transform: 'translateX(0)',
            boxShadow: '10px 0 20px rgba(0,0,0,0.2)'
        },
        sidebarHeader: { display: 'flex', alignItems: 'center', gap: '12px', borderBottom: '1px solid #334155', paddingBottom: '20px', marginBottom: '20px', position: 'relative' },
        profileImage: { width: '48px', height: '48px', borderRadius: '50%', objectFit: 'cover', border: '2px solid #475569' },
        profileName: { color: '#ffffff', fontSize: '1rem', fontWeight: '600', margin: 0 },
        profileRole: { color: '#94a3b8', fontSize: '0.8rem', margin: '4px 0 0', textTransform: 'capitalize' },
        nav: { display: 'flex', flexDirection: 'column', gap: '8px', flexGrow: 1, overflowY: 'auto' },
        navLink: { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 16px', textDecoration: 'none', color: '#cbd5e0', borderRadius: '8px', transition: 'background-color 0.2s ease, color 0.2s ease' },
        activeLink: { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 16px', textDecoration: 'none', borderRadius: '8px', backgroundColor: '#334155', color: '#ffffff', fontWeight: '600' },
        divider: { border: 'none', borderTop: '1px solid #334155', margin: '16px 0' },

        mainContainer: {
            width: '100%',
            display: 'flex',
            flexDirection: 'column'
        },
        mobileHeader: {
            display: 'flex',
            alignItems: 'center',
            padding: '16px',
            backgroundColor: '#ffffff',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            color: '#1e293b',
            zIndex: 900,
        },
        hamburgerButton: { background: 'none', border: 'none', cursor: 'pointer', color: '#1e293b', padding: 0 },
        mobileHeaderText: { marginLeft: '16px', fontSize: '1.1rem', fontWeight: '600' },
        closeButton: {
            position: 'absolute',
            top: '15px',
            right: '-5px',
            background: 'none',
            border: 'none',
            color: '#94a3b8',
            cursor: 'pointer'
        },

        content: { 
            flex: 1, 
            padding: '24px', 
            overflowY: 'auto' 
        },
        logoutButton: { display: 'flex', alignItems: 'center', gap: '12px', width: '100%', padding: '12px 16px', backgroundColor: 'transparent', color: '#cbd5e0', border: '1px solid #334155', borderRadius: '8px', cursor: 'pointer', textAlign: 'left', fontSize: '1rem', transition: 'background-color 0.2s ease, color 0.2s ease' },
        overlay: {
            position: 'fixed',
            top: MAIN_HEADER_HEIGHT,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 1050,
        },
    };

    return (
        <AdminContext.Provider value={{ profil }}>
            <div style={styles.layout}>
                {isSidebarOpen && <div style={styles.overlay} onClick={closeSidebar}></div>}

                <aside className="admin-sidebar" style={{...styles.sidebar, ...(isSidebarOpen ? styles.sidebarOpen : {})}}>
                    <div style={styles.sidebarHeader}>
                        <img src={profil.foto || `https://ui-avatars.com/api/?name=${profil.namaTampilan.replace(/\s/g, '+')}&background=334155&color=fff&font-size=0.5`} alt="Profil" style={styles.profileImage} />
                        <div>
                            <h2 style={styles.profileName}>{profil.namaTampilan}</h2>
                            <p style={styles.profileRole}>{profil.kementerian || profil.role}</p>
                        </div>
                        <button style={styles.closeButton} className="sidebar-close-button" onClick={closeSidebar}>
                            <X size={24} />
                        </button>
                    </div>
                    <nav style={styles.nav}>
                        {navLinks
                            .filter(item => !item.required || isAllowed(item.required))
                            .map(renderNavLink)
                        }
                        
                        <div className="nav-group">
                            <button className="nav-dropdown-toggle" onClick={() => toggleMenu('keterbukaanInformasi')}>
                                <div className="nav-link-content">
                                    <Landmark size={20} />
                                    <span>Informasi Publik</span>
                                </div>
                                <ChevronDown size={16} className={`chevron ${openMenus.keterbukaanInformasi ? 'open' : ''}`} />
                            </button>
                            {openMenus.keterbukaanInformasi && (
                                <div className="nav-submenu">
                                    {/* --- [PERBAIKAN] Menambahkan filter di sini juga --- */}
                                    {keterbukaanInformasiLinks
                                        .filter(item => !item.required || isAllowed(item.required))
                                        .map(renderNavLink)
                                    }
                                </div>
                            )}
                        </div>

                        {specialAccessLinks.some(link => isAllowed(link.required)) && <hr style={styles.divider} />}
                        {specialAccessLinks.filter(item => isAllowed(item.required)).map(renderNavLink)}
                        
                        {profil.role === 'master' && (
                            <>
                                <hr style={styles.divider} />
                                {masterLinks.map(renderNavLink)}
                            </>
                        )}
                    </nav>
                    <div style={{marginTop: 'auto'}}>
                        <button onClick={handleLogout} style={styles.logoutButton} className="logout-button">
                            <LogOut size={20} />
                            <span>Logout</span>
                        </button>
                    </div>
                </aside>

                <div style={styles.mainContainer}>
                    <header style={styles.mobileHeader} className="mobile-header">
                        <button style={styles.hamburgerButton} onClick={() => setSidebarOpen(true)}>
                            <Menu size={28} />
                        </button>
                        <span style={styles.mobileHeaderText}>Admin Dashboard</span>
                    </header>
                    <main className="admin-content" style={styles.content}>
                        <Outlet />
                    </main>
                </div>
            </div>
        </AdminContext.Provider>
    );
};

const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    /* Layout */
    .admin-layout { display: flex; min-height: 100vh; background-color: #f8fafc; }
    .main-container { flex: 1; display: flex; flex-direction: column; }
    .admin-content { flex: 1; padding: 24px; overflow-y: auto; }
    .overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0,0,0,0.5); z-index: 1050; }

    /* Sidebar */
    .admin-sidebar {
        background-color: #1e293b; color: #e2e8f0; width: 280px;
        position: fixed; top: 0; left: 0; height: 100%;
        display: flex; flex-direction: column; z-index: 1100;
        transform: translateX(-100%); transition: transform 0.3s ease-in-out;
    }
    .admin-sidebar.open { transform: translateX(0); box-shadow: 10px 0 20px rgba(0,0,0,0.2); }
    
    /* Sidebar Header */
    .sidebar-header { display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #334155; padding: 20px; position: relative; }
    .sidebar-header img { width: 48px; height: 48px; border-radius: 50%; object-fit: cover; border: 2px solid #475569; }
    .sidebar-header h2 { color: #ffffff; font-size: 1rem; font-weight: 600; margin: 0; }
    .sidebar-header p { color: #94a3b8; font-size: 0.8rem; margin: 4px 0 0; text-transform: capitalize; }
    .sidebar-close-button { position: absolute; top: 15px; right: 15px; background: none; border: none; color: #94a3b8; cursor: pointer; display: block; }
    
    /* Sidebar Navigation */
    .sidebar-nav { padding: 20px; display: flex; flex-direction: column; gap: 8px; flex-grow: 1; overflow-y: auto; }
    .sidebar-nav hr { border: none; border-top: 1px solid #334155; margin: 16px 0; }
    .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 16px; text-decoration: none; color: #cbd5e0; border-radius: 8px; transition: all 0.2s ease; }
    .nav-link.active { background-color: #334155; color: #ffffff; font-weight: 600; }
    .nav-link:hover:not(.active) { background-color: #334155; color: #ffffff; }

    /* Dropdown Menu Styles */
    .nav-group { display: flex; flex-direction: column; }
    .nav-dropdown-toggle { display: flex; align-items: center; justify-content: space-between; width: 100%; background: none; border: none; cursor: pointer; padding: 12px 16px; color: #cbd5e0; border-radius: 8px; transition: all 0.2s ease; }
    .nav-dropdown-toggle:hover { background-color: #334155; color: #ffffff; }
    .nav-link-content { display: flex; align-items: center; gap: 12px; }
    .chevron { transition: transform 0.2s ease-in-out; }
    .chevron.open { transform: rotate(180deg); }
    .nav-submenu { display: flex; flex-direction: column; gap: 4px; margin: 4px 0 0 16px; padding-left: 28px; border-left: 1px solid #475569; }

    /* Sidebar Footer */
    .sidebar-footer { padding: 20px; }
    .logout-button { display: flex; align-items: center; gap: 12px; width: 100%; padding: 12px 16px; background-color: transparent; color: #cbd5e0; border: 1px solid #334155; border-radius: 8px; cursor: pointer; text-align: left; font-size: 1rem; transition: all 0.2s ease; }
    .logout-button:hover { background-color: #b91c1c; border-color: #b91c1c; color: #ffffff; }
    
    /* Mobile Header */
    .mobile-header { display: flex; align-items: center; padding: 16px; background-color: #ffffff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); color: #1e293b; }
    .mobile-header button { background: none; border: none; cursor: pointer; color: #1e293b; padding: 0; }
    .mobile-header span { margin-left: 16px; font-size: 1.1rem; font-weight: 600; }

    /* Responsive */
    @media (min-width: 1024px) {
        .admin-layout { display: block; } /* Kembali ke block agar margin-left bekerja */
        .main-container { padding-left: 280px; }
        .admin-sidebar { transform: translateX(0); box-shadow: none !important; }
        .mobile-header, .sidebar-close-button, .overlay { display: none; }
        .admin-content { padding: 32px; }
    }
`;
document.head.appendChild(styleSheet);

export default AdminLayout;